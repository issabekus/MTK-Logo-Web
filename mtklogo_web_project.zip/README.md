# MTKLogo Web by issabekus
Инструкция запуска:
1. pip install -r requirements.txt
2. python app.py